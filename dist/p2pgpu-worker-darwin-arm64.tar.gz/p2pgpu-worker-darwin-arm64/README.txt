p2pgpu volunteer worker
=======================

WHAT THIS DOES
  Runs GPU compute for a research project on distributed computing. It
  contributes spare GPU time to a job and sends back results.

WHAT IT DOES NOT DO
  It reads no files of yours, opens no ports, and installs nothing. It makes
  ONE outbound WebSocket connection to the coordinator URL you pass it, and
  stops the moment you press Ctrl-C.

TO RUN
  ./join ws://HOST:PORT/ws

TO STOP
  Ctrl-C. Any work in progress is handed back to the coordinator
  automatically — nothing is lost by quitting at any moment.

TO CHECK WHAT GPU IT SEES, WITHOUT CONTRIBUTING ANYTHING
  ./worker-native adapter

USEFUL EXTRAS
  ./join ws://HOST:PORT/ws --throttle 0.5     use ~half the GPU
